# Active development is on the master branch now.

TODO: add more specific contributing guidelines. In general...

1. Please make sure your code follows the [java naming conventions](https://www.geeksforgeeks.org/java-naming-conventions/).
2. Please refactor your code where possible. Refer to surrounding code for reference (TODO: we need to refactor the entire codebase right now. Just follow good coding practices).
3. Generally, most PRs will be merged. When in doubt about a new feature, make an issue first before writing it -- issues are free, your development time is not :)
