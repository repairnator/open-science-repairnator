package featurecat.lizzie.analysis;

import java.util.List;

public interface LeelazListener {
  void bestMoveNotification(List<MoveData> bestMoves);
}
