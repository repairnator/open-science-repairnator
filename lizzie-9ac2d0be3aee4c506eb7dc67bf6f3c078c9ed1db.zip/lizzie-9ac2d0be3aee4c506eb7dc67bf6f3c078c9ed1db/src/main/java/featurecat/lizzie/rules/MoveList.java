package featurecat.lizzie.rules;

public class MoveList {
  public boolean isPass;
  public int x;
  public int y;
  public int moveNum;
  public boolean isBlack;
}
